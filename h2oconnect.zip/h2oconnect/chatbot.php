<?php
require_once 'controllers/chatbotController.php';

$controller = new ChatbotController();
$controller->handleRequest();
?>
