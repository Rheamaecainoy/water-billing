<?php
require_once 'models/dashboardcustomerModel.php';

class DashboardCustomerController {
    public function handleRequest() {
        if (!isset($_SESSION['customer_id'])) {
            header("Location: login_customer.php");
            exit();
        }

        $model = new DashboardCustomerModel();
        $customer_id = $_SESSION['customer_id'];

        $unpaid = $model->getUnpaidBill($customer_id);
        $paid_bills = $model->getRecentPaidBills($customer_id);

        return [
            'unpaid' => $unpaid,
            'paid_bills' => $paid_bills
        ];
    }
}
