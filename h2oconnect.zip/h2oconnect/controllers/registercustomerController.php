<?php
require_once 'models/registercustomerModel.php';

class RegisterCustomerController {
    private $model;

    public function __construct() {
        $this->model = new RegisterCustomerModel();
    }

    public function handleRequest() {
        $msg = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $full_name = trim($_POST['full_name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']);
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

            $success = $this->model->registerCustomer($full_name, $email, $phone, $password);

            if ($success) {
                $msg = "Registration successful. <a href='login_customer.php'>Login here</a>.";
            } else {
                $msg = "Registration failed. Email might already be used.";
            }
        }

        include 'views/register_customer.php';
    }
}
