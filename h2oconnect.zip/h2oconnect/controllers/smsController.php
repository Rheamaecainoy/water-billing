<?php
require_once 'models/smsModel.php';

class SmsController {
    public function handleRequest() {
        $model = new SmsModel();

        $message_sent = false;
        $error_message = "";
        $prefill_phone = isset($_GET['recipient']) ? htmlspecialchars($_GET['recipient']) : '';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $recipient = trim($_POST["recipient"]);
            $message = trim($_POST["message"]);
            list($message_sent, $error_message) = $model->sendSms($recipient, $message);
        }

        include 'views/sms.php';
    }
}
