<?php
include 'db.php';
include 'models/saleschartModel.php';

// Sanitize period input
$period = $_GET['period'] ?? 'monthly';
$validPeriods = ['daily', 'monthly', 'yearly'];
if (!in_array($period, $validPeriods)) {
    $period = 'monthly';
}

// Define the date condition and label BEFORE using it
switch ($period) {
    case 'daily':
        $dateCondition = "DATE(paid_at) = CURDATE()";
        $label = "Today (" . date('M d, Y') . ")";
        break;
    case 'yearly':
        $dateCondition = "YEAR(paid_at) = YEAR(CURDATE())";
        $label = "Year " . date('Y');
        break;
    case 'monthly':
    default:
        $dateCondition = "YEAR(paid_at) = YEAR(CURDATE()) AND MONTH(paid_at) = MONTH(CURDATE())";
        $label = date('F Y');
        break;
}

// Now it's safe to use $dateCondition
$model = new SalesChartModel($pdo);
$totalBillings = $model->getTotalBillings($dateCondition);
$unpaidCustomers = $model->getUnpaidCustomers();
$overdueCount = $model->getOverdueCount();
$totalCustomers = $model->getTotalCustomers();
$incomeTax = $totalBillings * 0.02;

// Send data to view
include 'views/saleschart.php';
