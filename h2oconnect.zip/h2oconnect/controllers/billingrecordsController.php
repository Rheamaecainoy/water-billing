<?php
require_once 'models/billingrecordsModel.php';

class BillingRecordsController {
    private $model;

    public function __construct($pdo) {
        $this->model = new BillingRecordsModel($pdo);
    }

    public function handleRequest() {
        if (!isset($_SESSION['customer_id'])) {
            header("Location: login_customer.php");
            exit();
        }

        $customer_id = $_SESSION['customer_id'];
        $records = $this->model->getBillingRecordsByCustomer($customer_id);

        require 'views/billingrecords.php';
    }
}
