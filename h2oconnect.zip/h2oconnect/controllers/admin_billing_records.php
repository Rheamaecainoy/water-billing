<?php
require_once 'models/admin_billing_recordsModel.php';

class AdminBillingRecordsController {
    public function handleRequest() {
        $filter = isset($_GET['search']) ? trim($_GET['search']) : '';
        $model = new AdminBillingRecordsModel();
        $records = $model->getBillingRecords($filter);

        include 'views/admin_billing_records.php';
    }
}
