<?php
require_once 'models/profileModel.php';

class ProfileController {
    private $model;
    private $customer_id;

    public function __construct() {
        $this->model = new ProfileModel();
        $this->customer_id = $_SESSION['customer_id'];
    }

    public function handleRequest() {
        $success = "";
        $error = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $full_name = trim($_POST['full_name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']);
            $password = $_POST['password'];

            // Validate inputs
            if (empty($full_name) || empty($email)) {
                $error = "Full Name and Email are required.";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Please enter a valid email address.";
            } elseif ($this->model->isEmailUsedByOthers($email, $this->customer_id)) {
                $error = "Email is already in use by another account.";
            } else {
                // Prepare data to update
                $updateData = [
                    'full_name' => $full_name,
                    'email' => $email,
                    'phone' => $phone,
                    'id' => $this->customer_id
                ];

                if (!empty($password)) {
                    if (strlen($password) < 6) {
                        $error = "Password must be at least 6 characters.";
                    } else {
                        $updateData['password'] = password_hash($password, PASSWORD_DEFAULT);
                    }
                }

                if (!$error) {
                    $updated = $this->model->updateProfile($updateData);
                    if ($updated) {
                        $success = "Profile updated successfully.";
                    } else {
                        $error = "Failed to update profile.";
                    }
                }
            }
        }

        // Fetch current data
        $user = $this->model->getUserById($this->customer_id);
        if (!$user) {
            die("User not found.");
        }

        // Load the view
        require 'views/profile.php';
    }
}
