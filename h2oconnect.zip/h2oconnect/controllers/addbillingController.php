<?php
class AddBillingController {
    private $model;
    private $message = '';

    public function __construct($model) {
        $this->model = $model;
    }

    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $customer_id = $_POST['customer_id'];
            $amount = $_POST['amount'];
            $due_date = $_POST['due_date'];

            if (!empty($customer_id) && !empty($amount) && !empty($due_date)) {
                if ($this->model->addBilling($customer_id, $amount, $due_date)) {
                    $this->message = "✅ Billing record added successfully.";
                } else {
                    $this->message = "❌ Failed to add billing record.";
                }
            } else {
                $this->message = "⚠️ All fields are required.";
            }
        }
    }

    public function getMessage() {
        return $this->message;
    }
}
