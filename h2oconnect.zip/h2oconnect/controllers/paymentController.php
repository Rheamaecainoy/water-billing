<?php
require_once 'models/paymentModel.php';

class PaymentController {
    public function handleRequest() {
        if (!isset($_SESSION['customer_id'])) {
            header("Location: login_customer.php");
            exit();
        }

        $customer_id = $_SESSION['customer_id'];
        $billing_id = $_GET['billing_id'] ?? null;

        $model = new PaymentModel();
        $bill = $model->getUnpaidBill($billing_id, $customer_id);

        if (!$bill) {
            echo "<h3 style='text-align:center;color:red;'>Invalid or already paid billing record.</h3>";
            exit();
        }

        $baseAmount = $bill['amount'];
        $processingFee = round($baseAmount * 0.02, 2);
        $totalAmount = $baseAmount + $processingFee;

        $payment_done = false;
        $selected_method = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $selected_method = htmlspecialchars($_POST['pay_method'] ?? '');

            if ($selected_method) {
                $model->markAsPaid($billing_id, $customer_id);
                $payment_done = true;
            }
        }

        // Pass data to view
        include 'views/payment.php';
    }
}
