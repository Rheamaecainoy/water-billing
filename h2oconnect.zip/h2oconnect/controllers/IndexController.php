<?php
class IndexController {
    public function index() {
        include 'views/index.php';
    }
}
