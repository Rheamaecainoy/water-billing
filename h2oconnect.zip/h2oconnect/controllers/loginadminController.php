<?php
require_once 'models/loginadminModel.php';

class LoginAdminController {
    private $model;

    public function __construct() {
        $this->model = new LoginAdminModel();
    }

    public function handleRequest() {
        // Redirect if already logged in
        if (isset($_SESSION['admin_id'])) {
            header("Location: dashboard_admin.php");
            exit();
        }

        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];

            if (!empty($email) && !empty($password)) {
                $admin = $this->model->getAdminByEmail($email);

                if ($admin && password_verify($password, $admin['password'])) {
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_username'] = $admin['username'];

                    header("Location: dashboard_admin.php");
                    exit();
                } else {
                    $error = "Invalid email or password.";
                }
            } else {
                $error = "All fields are required.";
            }
        }

        include 'views/login_admin.php';
    }
}
