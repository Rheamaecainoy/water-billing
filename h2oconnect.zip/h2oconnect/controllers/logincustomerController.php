<?php
require_once 'models/logincustomerModel.php';

class LoginCustomerController {
    private $model;

    public function __construct() {
        $this->model = new LoginCustomerModel();
    }

    public function handleRequest() {
        $error = '';
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];

            $user = $this->model->getUserByEmail($email);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['customer_id'] = $user['id'];
                $_SESSION['customer_name'] = $user['full_name'];
                header("Location: dashboard_customer.php");
                exit;
            } else {
                $error = "Invalid email or password.";
            }
        }

        include 'views/login_customer.php';
    }
}
