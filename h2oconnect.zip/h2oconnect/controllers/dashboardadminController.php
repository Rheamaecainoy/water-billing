<?php
require_once 'models/dashboardadminModel.php';

class DashboardAdminController {
    public function handleRequest() {
    if (!isset($_SESSION['admin_id'])) {
        header("Location: login_admin.php");
        exit;
    }

    $model = new DashboardAdminModel();

    // Handle deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['delete_customer_id'])) {
            $model->deleteCustomer((int)$_POST['delete_customer_id']);
        }
        if (isset($_POST['delete_admin_id'])) {
            // Prevent self-deletion
            if ($_POST['delete_admin_id'] != $_SESSION['admin_id']) {
                $model->deleteAdmin((int)$_POST['delete_admin_id']);
            }
        }
        // Refresh to avoid resubmission
        header("Location: dashboard_admin.php");
        exit;
    }

    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $adminSearch = isset($_GET['admin_search']) ? trim($_GET['admin_search']) : '';

    $customers = $model->getCustomers($search);
    $admins = $model->getAdmins($adminSearch);

    include 'views/dashboardadmin.php';
}

}