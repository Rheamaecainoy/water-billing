<?php
require_once 'models/chatbotModel.php';

class ChatbotController {
    public function handleRequest() {
        $model = new ChatbotModel();
        $suggestions = $model->getSuggestions();
        $answers = $model->getAnswers();
        include 'views/chatbot.php';
    }
}
