<?php
require_once 'models/generatepdf.model.php';
require_once 'views/generate_pdf.view.php';

class GeneratePDFController {
    public function handleRequest() {
        if (!isset($_GET['id'])) {
            die('Billing ID is required.');
        }

        $id = intval($_GET['id']);
        $model = new GeneratePDFModel();
        $record = $model->getBillingRecordWithCustomer($id);

        if (!$record) {
            die('Billing record not found.');
        }

        // Call the view function to generate PDF
        generatePDFView($record);
    }
}
