<?php
require_once 'models/register_adminModel.php';

class RegisterAdminController {
    public function handleRequest() {
        $model = new RegisterAdminModel();
        $msg = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $fullName = $_POST['full_name'] ?? '';
            $email = $_POST['email'] ?? '';
            $phone = $_POST['phone'] ?? '';
            $password = $_POST['password'] ?? '';

            $msg = $model->registerAdmin($fullName, $email, $phone, $password);
        }

        include 'views/register_admin.php';
    }
}
