<?php
require_once 'db.php';
require_once 'models/helpModel.php';

class HelpController {
    private $model;

    public function __construct() {
        global $pdo;  // from db.php
        $this->model = new HelpModel($pdo);
    }

    public function index() {
        $admin = $this->model->getAdminContact();

        // Pass data to the view
        require 'views/help.php';
    }
}
