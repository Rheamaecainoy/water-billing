<?php
require_once 'controllers/smsController.php';

$smsController = new SmsController();
$smsController->handleRequest();
