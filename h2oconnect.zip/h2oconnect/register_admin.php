<?php
require_once 'controllers/register_adminController.php';

$controller = new RegisterAdminController();
$controller->handleRequest();
?>
