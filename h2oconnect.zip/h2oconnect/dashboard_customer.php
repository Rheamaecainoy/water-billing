<?php
session_start();
include 'controllers/dashboardcustomerController.php';

$controller = new DashboardCustomerController();
$data = $controller->handleRequest();

include 'views/dashboardcustomer.php';
