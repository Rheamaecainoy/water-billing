<?php
require_once 'controllers/IndexController.php';

$controller = new IndexController();
$controller->index();
