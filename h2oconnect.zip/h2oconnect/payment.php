<?php
session_start();
require_once 'controllers/paymentController.php';

$controller = new PaymentController();
$controller->handleRequest();
