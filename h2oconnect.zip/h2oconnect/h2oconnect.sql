-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2025 at 02:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `h2oconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'Admin01', 'Admin01@gmail.com', '$2y$10$2ZaGH22MZFnLi.TdvutLyO01qeasiuy1mNLkApnQivZMkCJL1mvAG', '2025-05-18 13:49:02'),
(2, 'Admin02', 'Admin02@gmail.com', '$2y$10$VUpZY3AN6MfyRb3331G/e.e5.1dwS8DXbEr/rhA3VdP2ifg8PwG7S', '2025-05-19 11:50:22');

-- --------------------------------------------------------

--
-- Table structure for table `billing_records`
--

CREATE TABLE `billing_records` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('unpaid','paid','overdue') DEFAULT 'unpaid',
  `paid_at` timestamp NULL DEFAULT NULL,
  `due_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing_records`
--

INSERT INTO `billing_records` (`id`, `customer_id`, `amount`, `status`, `paid_at`, `due_date`, `created_at`) VALUES
(2, 1, 2000.00, 'paid', '2025-05-18 15:19:20', '2025-05-20', '2025-05-18 14:07:32'),
(3, 1, 1500.00, 'paid', '2025-05-18 15:21:17', '2025-05-21', '2025-05-18 15:20:51'),
(4, 1, 3000.00, 'paid', '2025-05-18 15:24:02', '2025-05-19', '2025-05-18 15:23:09'),
(5, 1, 1000.00, 'paid', '2025-05-18 15:44:41', '2025-05-19', '2025-05-18 15:23:32'),
(6, 1, 1500.00, 'paid', '2025-05-18 15:51:59', '2025-05-19', '2025-05-18 15:45:32'),
(7, 1, 2000.00, 'paid', '2025-05-18 15:55:25', '2025-05-19', '2025-05-18 15:45:47'),
(8, 1, 4000.00, 'paid', '2025-05-18 15:57:08', '2025-05-22', '2025-05-18 15:56:28'),
(9, 1, 5000.00, 'paid', '2025-05-18 15:58:14', '2025-05-24', '2025-05-18 15:56:40'),
(10, 1, 1000.00, 'paid', '2025-05-18 16:10:07', '2025-05-25', '2025-05-18 16:04:31'),
(11, 1, 2000.00, 'paid', '2025-05-18 16:05:12', '2025-05-20', '2025-05-18 16:04:50'),
(12, 2, 3000.00, 'paid', '2025-05-18 16:13:16', '2025-05-20', '2025-05-18 16:12:27'),
(13, 1, 1000.00, 'paid', '2025-05-18 16:16:07', '2025-05-20', '2025-05-18 16:12:37'),
(14, 1, 2000.00, 'paid', '2025-05-19 02:35:27', '2025-05-20', '2025-05-18 16:12:50'),
(15, 2, 1000.00, 'overdue', NULL, '2025-05-18', '2025-05-19 03:12:18'),
(16, 2, 2000.00, 'overdue', NULL, '2025-05-17', '2025-05-19 03:22:12'),
(17, 1, 2500.00, 'paid', '2025-05-19 06:59:22', '2025-05-20', '2025-05-19 03:49:21'),
(18, 3, 1000.00, 'paid', '2025-05-19 07:14:12', '2025-05-20', '2025-05-19 07:12:45'),
(19, 3, 2000.00, 'paid', '2025-05-19 07:14:58', '2025-05-20', '2025-05-19 07:12:55');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `full_name`, `email`, `password`, `created_at`, `phone`) VALUES
(1, 'Rhea mae cainoy', 'Rhea@gmail.com', '$2y$10$33X5Wa5Ot/atjXXeRb5NROzIOjwcZ318UaBoeRcIQO5w.W4R/QlK6', '2025-05-18 13:21:41', '09662196944'),
(2, 'Johan salazar', 'Johan@gmail.com', '$2y$10$EMh95U5nlJcX.mhwsdodDOfF7lXfaXiyJ8zDTzAW/Ghs/Abmho2vS', '2025-05-18 16:11:41', '09921551823'),
(3, 'Kevin Bermosa', 'Kevin@gmail.com', '$2y$10$l2iQUS46TAtDEbJKwb6Ju.aBhqgpBCcyE4GcgyaH4zIsdoTtQelIq', '2025-05-19 07:11:19', '09565213188');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `billing_records`
--
ALTER TABLE `billing_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `billing_records`
--
ALTER TABLE `billing_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `billing_records`
--
ALTER TABLE `billing_records`
  ADD CONSTRAINT `billing_records_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
