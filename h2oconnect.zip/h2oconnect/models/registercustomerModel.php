<?php
require_once 'db.php';

class RegisterCustomerModel {
    public function registerCustomer($full_name, $email, $phone, $password) {
        global $pdo;

        $stmt = $pdo->prepare("INSERT INTO customers (full_name, email, phone, password) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$full_name, $email, $phone, $password]);
    }
}
