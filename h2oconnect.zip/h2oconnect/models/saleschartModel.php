<?php
class SalesChartModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getTotalBillings($condition) {
        $stmt = $this->pdo->prepare("SELECT SUM(amount) AS total_billings FROM billing_records WHERE status = 'paid' AND $condition");
        $stmt->execute();
        return floatval($stmt->fetch()['total_billings'] ?? 0);
    }

    public function getUnpaidCustomers() {
        $stmt = $this->pdo->query("SELECT COUNT(*) AS unpaid_customers FROM billing_records WHERE status = 'unpaid'");
        return intval($stmt->fetch()['unpaid_customers'] ?? 0);
    }

    public function getOverdueCount() {
        $stmt = $this->pdo->query("SELECT COUNT(*) AS overdue_count FROM billing_records WHERE status = 'overdue'");
        return intval($stmt->fetch()['overdue_count'] ?? 0);
    }

    public function getTotalCustomers() {
        $stmt = $this->pdo->query("SELECT COUNT(*) AS total_customers FROM customers");
        return intval($stmt->fetch()['total_customers'] ?? 0);
    }
}
