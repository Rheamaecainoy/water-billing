<?php
require_once 'db.php';

class DashboardCustomerModel {
    public function getUnpaidBill($customer_id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM billing_records WHERE customer_id = ? AND status = 'unpaid' ORDER BY due_date ASC LIMIT 1");
        $stmt->execute([$customer_id]);
        return $stmt->fetch();
    }

    public function getRecentPaidBills($customer_id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM billing_records WHERE customer_id = ? AND status = 'paid' ORDER BY created_at DESC LIMIT 5");
        $stmt->execute([$customer_id]);
        return $stmt->fetchAll();
    }
}
