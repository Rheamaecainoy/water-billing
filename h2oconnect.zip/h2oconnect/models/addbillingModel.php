<?php
class AddBillingModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function addBilling($customer_id, $amount, $due_date) {
        $stmt = $this->pdo->prepare("INSERT INTO billing_records (customer_id, amount, due_date) VALUES (?, ?, ?)");
        return $stmt->execute([$customer_id, $amount, $due_date]);
    }

    public function getCustomers() {
        $stmt = $this->pdo->query("SELECT id, full_name FROM customers ORDER BY full_name ASC");
        return $stmt->fetchAll();
    }
}
