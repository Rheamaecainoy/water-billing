<?php
class ChatbotModel {
    public function getSuggestions() {
        return [
            "How do I request a refund?",
            "How long does a refund take?",
            "Why was my refund denied?"
        ];
    }

    public function getAnswers() {
        return [
            "To request a refund, go to your order history, select the item, and click 'Request Refund'. Follow the on-screen instructions.",
            "Refunds typically take 5-10 business days to process depending on your payment method.",
            "Refunds can be denied for several reasons such as policy violations, expired eligibility, or insufficient documentation."
        ];
    }
}
