<?php
require_once 'db.php';

class GeneratePDFModel {
    public function getBillingRecordWithCustomer($id) {
        global $pdo;
        $sql = "SELECT b.*, c.full_name, c.email 
                FROM billing_records b 
                JOIN customers c ON b.customer_id = c.id 
                WHERE b.id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}
