<?php
require_once 'db.php';

class DashboardAdminModel {
    private $pdo;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
    }

    public function getCustomers($search = '') {
        $query = "SELECT * FROM customers";
        $params = [];

        if (!empty($search)) {
            $query .= " WHERE full_name LIKE ?";
            $params[] = "%$search%";
        }

        $query .= " ORDER BY created_at DESC";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getAdmins($adminSearch = '') {
        $query = "SELECT * FROM admins";
        $params = [];

        if (!empty($adminSearch)) {
            $query .= " WHERE username LIKE ?";
            $params[] = "%$adminSearch%";
        }

        $query .= " ORDER BY created_at DESC";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function deleteCustomer($id) {
        $stmt = $this->pdo->prepare("DELETE FROM customers WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function deleteAdmin($id) {
        $stmt = $this->pdo->prepare("DELETE FROM admins WHERE id = ?");
        $stmt->execute([$id]);
    }
}
