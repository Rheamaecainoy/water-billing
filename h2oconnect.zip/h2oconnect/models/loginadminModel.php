<?php
require_once 'db.php';

class LoginAdminModel {
    public function getAdminByEmail($email) {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }
}
