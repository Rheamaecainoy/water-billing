<?php
require_once 'db.php'; // Assumes $pdo is defined here

class RegisterAdminModel {
    public function registerAdmin($fullName, $email, $phone, $password) {
        global $pdo;

        // Validate input (basic example)
        if (empty($fullName) || empty($email) || empty($phone) || empty($password)) {
            return '⚠️ All fields are required.';
        }

        // Check for existing email
         $check = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
        $check->execute([$email]);
        if ($check->rowCount() > 0) {
            return '❌ Email is already registered.';
        }

        // Insert admin record
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admins (username, email, password) VALUES (?, ?, ?)");

        if ($stmt->execute([$fullName, $email, $hashedPassword])) {
    return '✅ Admin registered successfully.';
}
 else {
            return '❌ Failed to register admin.';
        }
    }
}

?>
