<?php
require_once 'db.php'; // your PDO $pdo connection

class ProfileModel {
    private $pdo;

    public function __construct() {
        global $pdo;
        $this->pdo = $pdo;
    }

    public function getUserById($id) {
        $stmt = $this->pdo->prepare("SELECT full_name, email, phone FROM customers WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function isEmailUsedByOthers($email, $excludeId) {
        $stmt = $this->pdo->prepare("SELECT id FROM customers WHERE email = :email AND id != :id");
        $stmt->execute(['email' => $email, 'id' => $excludeId]);
        return (bool) $stmt->fetch();
    }

    public function updateProfile($data) {
        if (isset($data['password'])) {
            $sql = "UPDATE customers SET full_name = :full_name, email = :email, phone = :phone, password = :password WHERE id = :id";
        } else {
            $sql = "UPDATE customers SET full_name = :full_name, email = :email, phone = :phone WHERE id = :id";
        }
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($data);
    }
}
