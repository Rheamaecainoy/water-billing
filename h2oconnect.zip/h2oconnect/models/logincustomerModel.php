<?php
require_once 'db.php';

class LoginCustomerModel {
    public function getUserByEmail($email) {
        global $pdo;

        $stmt = $pdo->prepare("SELECT * FROM customers WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }
}
