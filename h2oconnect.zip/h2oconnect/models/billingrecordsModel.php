<?php

class BillingRecordsModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getBillingRecordsByCustomer($customer_id) {
        $sql = "SELECT * FROM billing_records WHERE customer_id = ? ORDER BY due_date DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$customer_id]);
        return $stmt->fetchAll();
    }
}
