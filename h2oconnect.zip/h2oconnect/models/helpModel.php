<?php
class HelpModel {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getAdminContact() {
        $stmt = $this->pdo->query("SELECT username, email FROM admins LIMIT 1");
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
