<?php
require_once 'db.php';

class PaymentModel {
    private $pdo;

    public function __construct() {
        global $pdo; // uses db.php connection
        $this->pdo = $pdo;
    }

    public function getUnpaidBill($billing_id, $customer_id) {
        $stmt = $this->pdo->prepare("SELECT * FROM billing_records WHERE id = ? AND customer_id = ? AND status = 'unpaid'");
        $stmt->execute([$billing_id, $customer_id]);
        return $stmt->fetch();
    }

    public function markAsPaid($billing_id, $customer_id) {
        $stmt = $this->pdo->prepare("UPDATE billing_records SET status = 'paid', paid_at = NOW() WHERE id = ? AND customer_id = ?");
        return $stmt->execute([$billing_id, $customer_id]);
    }
}
