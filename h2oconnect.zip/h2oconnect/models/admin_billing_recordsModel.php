<?php
require_once 'db.php';

class AdminBillingRecordsModel {
    public function getBillingRecords($filter) {
        global $pdo;

        $sql = "SELECT b.id, c.full_name, c.email, c.phone, b.amount, b.status, b.due_date, b.created_at, b.paid_at
                FROM billing_records b
                JOIN customers c ON b.customer_id = c.id";

        if (!empty($filter)) {
            if ($filter === 'unpaid') {
                $sql .= " WHERE b.status = 'unpaid'";
            } elseif ($filter === 'overdue') {
                $sql .= " WHERE b.status = 'overdue'";
            } elseif ($filter === 'paid') {
                $sql .= " WHERE b.status = 'paid'";
            } elseif ($filter === 'tax') {
                $sql .= " WHERE b.amount > 0";
            }
        }

        $sql .= " ORDER BY b.due_date DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
