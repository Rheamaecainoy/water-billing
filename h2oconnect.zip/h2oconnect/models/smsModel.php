<?php

class SmsModel {
    private $api_url = "https://app.philsms.com/api/v3/sms/send";
    private $api_key = "1870|igx1UubHUofUi2cyOjISRWKV9YjG8dbZGC4UUQvF";

    public function sendSms($recipient, $message) {
        $error_message = "";
        $message_sent = false;

        $sender_id = "PhilSMS";
        $type = "plain";

        if (empty($recipient) || empty($message)) {
            $error_message = "Please enter both recipient number and message.";
        } elseif (!preg_match('/^09[0-9]{9}$/', $recipient)) {
            $error_message = "Recipient number must start with 09 and be 11 digits long.";
        } else {
            $recipient = '+63' . substr($recipient, 1);

            $post_fields = [
                "recipient" => $recipient,
                "sender_id" => $sender_id,
                "type" => $type,
                "message" => $message
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->api_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json",
                "Authorization: Bearer {$this->api_key}",
                "Accept: application/json"
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_fields));

            $result = curl_exec($ch);

            if (curl_errno($ch)) {
                $error_message = "cURL error: " . curl_error($ch);
            } else {
                $response = json_decode($result, true);
                if (isset($response["status"]) && $response["status"] === "success") {
                    $message_sent = true;
                } else {
                    $error_message = "Failed to send SMS: " . ($response["message"] ?? "Unknown error");
                }
            }

            curl_close($ch);
        }

        return [$message_sent, $error_message];
    }
}
