<?php
session_start();

if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit;
}

require_once 'controllers/profileController.php';

$controller = new ProfileController();
$controller->handleRequest();
