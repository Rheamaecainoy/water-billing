<?php
session_start();
require_once 'controllers/loginadminController.php';

$controller = new LoginAdminController();
$controller->handleRequest();
