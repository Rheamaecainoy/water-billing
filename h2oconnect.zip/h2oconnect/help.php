<?php
session_start();

require_once 'controllers/helpController.php';

$controller = new HelpController();
$controller->index();
