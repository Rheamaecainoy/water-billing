<?php
require_once 'db.php';
require_once 'models/addbillingModel.php';
require_once 'controllers/addbillingController.php';

$model = new AddBillingModel($pdo);
$controller = new AddBillingController($model);
$controller->handleRequest();

$customers = $model->getCustomers();
$message = $controller->getMessage();

include 'views/addbilling.php';
