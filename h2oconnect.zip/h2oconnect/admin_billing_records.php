<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login_admin.php");
    exit();
}

require_once 'controllers/admin_billing_records.php';

$controller = new AdminBillingRecordsController();
$controller->handleRequest();
