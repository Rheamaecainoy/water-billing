<?php
require_once 'controllers/registercustomerController.php';

$controller = new RegisterCustomerController();
$controller->handleRequest();
