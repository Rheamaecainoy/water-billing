<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sales Charts - H2OConnect</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: url('1.jpg') no-repeat center center fixed;
      background-size: cover;
      color: white;
    }
    h1, h2, td {
      color: white;
    }
    h1 {
      color: darkblue;
      text-shadow: white;
      text-align: center;
      margin: 30px 0 10px;
    }
    form {
      text-align: center;
      margin-bottom: 30px;
    }
    select {
      padding: 8px 12px;
      border-radius: 6px;
      font-weight: bold;
      background-color: rgb(255, 255, 255);
      color: #000;
      cursor: pointer;
    }
    .chart-box {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 40px;
      padding: 20px;
    }
    .chart-container {
      background-color: rgba(43, 32, 32, 0.62);
      padding: 20px;
      border-radius: 10px;
      width: 300px;
      box-shadow: 0 0 20px #007bffaa;
      text-align: center;
    }
    canvas {
      max-width: 100%;
      height: auto;
    }
    footer {
      margin-top: 40px;
      text-align: center;
      color: #ffffff;
    }
    .chart-container a {
      display: block;
      height: 100%;
      width: 100%;
      text-decoration: none; /* Remove underline */
    }
    .chart-container a:hover {
      opacity: 0.8; /* Slightly fade on hover */
    }
  </style>
</head>
<body>

<h1>Sales Breakdown — <?php echo htmlspecialchars($label); ?></h1>

<form method="get">
  <label>Select Period:</label>
  <select name="period" onchange="this.form.submit()">
    <option value="daily" <?= $period === 'daily' ? 'selected' : '' ?>>Daily</option>
    <option value="monthly" <?= $period === 'monthly' ? 'selected' : '' ?>>Monthly</option>
    <option value="yearly" <?= $period === 'yearly' ? 'selected' : '' ?>>Yearly</option>
  </select>
</form>

<div class="chart-box">
  <div class="chart-container">
    <h3>Total Billings</h3>
    <a href="admin_billing_records.php?search=paid">
      <canvas id="chart1"></canvas>
    </a>
  </div>

  <div class="chart-container">
    <h3>Unpaid Customers</h3>
    <a href="admin_billing_records.php?search=unpaid">
      <canvas id="chart2"></canvas>
    </a>
  </div>

  <div class="chart-container">
    <h3>2% Income (Tax)</h3>
    <a href="admin_billing_records.php?search=tax">
      <canvas id="chart3"></canvas>
    </a>
  </div>

  <div class="chart-container">
    <h3>Total Customers</h3>
    <a href="admin_billing_records.php?search=total">
      <canvas id="chart4"></canvas>
    </a>
  </div>

  <div class="chart-container">
    <h3>Overdue Billings</h3>
    <a href="admin_billing_records.php?search=overdue">
      <canvas id="chart5"></canvas>
    </a>
  </div>
</div>

<script>
  const peso = (v) => '₱' + parseFloat(v).toLocaleString('en-PH', {minimumFractionDigits: 2});

  const commonOptions = {
    plugins: {
      tooltip: {
        callbacks: {
          label: ctx => peso(ctx.parsed)
        }
      },
      legend: {
        labels: {
          color: '#ffffff'
        }
      }
    }
  };

  const totalBillings = <?= $totalBillings ?>;
if (totalBillings > 0) {
  new Chart(document.getElementById('chart1'), {
    type: 'pie',
    data: {
      labels: ['Total Billings', 'Remaining (₱0 baseline)'],
      datasets: [{
        data: [totalBillings, 0],
        backgroundColor: ['#007bff', '#2f2f3d']
      }]
    },
    options: commonOptions
  });
} else {
  document.getElementById('chart1').parentElement.innerHTML += "<p style='color:white;'>No billing data for today.</p>";
}


  new Chart(document.getElementById('chart2'), {
    type: 'pie',
    data: {
      labels: ['Unpaid Customers', 'Others'],
      datasets: [{
        data: [<?= $unpaidCustomers ?>, Math.max(<?= $totalCustomers ?> - <?= $unpaidCustomers ?>, 0)],
        backgroundColor: ['#ff6384', '#3d3d5c']
      }]
    },
    options: {
      plugins: {
        legend: {
          labels: {
            color: '#ffffff'
          }
        }
      }
    }
  });

  const incomeTax = <?= $incomeTax ?>;
if (incomeTax > 0) {
  new Chart(document.getElementById('chart3'), {
    type: 'pie',
    data: {
      labels: ['2% Tax Income', 'Remaining (₱0 baseline)'],
      datasets: [{
        data: [incomeTax, 0],
        backgroundColor: ['#ffcd56', '#2f2f3d']
      }]
    },
    options: commonOptions
  });
} else {
  document.getElementById('chart3').parentElement.innerHTML += "<p style='color:white;'>No tax income for today.</p>";
}


  new Chart(document.getElementById('chart4'), {
    type: 'pie',
    data: {
      labels: ['Total Customers'],
      datasets: [{
        data: [<?= $totalCustomers ?>],
        backgroundColor: ['#36a2eb']
      }]
    },
    options: {
      plugins: {
        legend: {
          labels: {
            color: '#ffffff'
          }
        }
      }
    }
  });

  new Chart(document.getElementById('chart5'), {
    type: 'pie',
    data: {
      labels: ['Overdue Bills', 'Others'],
      datasets: [{
        data: [<?= $overdueCount ?>, Math.max(<?= $totalCustomers ?> - <?= $overdueCount ?>, 0)],
        backgroundColor: ['#dc3545', '#3d3d5c']
      }]
    },
    options: {
      plugins: {
        legend: {
          labels: {
            color: '#ffffff'
          }
        }
      }
    }
  });
</script>

<footer>© 2025 H2OConnect</footer>

</body>
</html>
