<!DOCTYPE html>
<html>
<head>
    <title>My Billing Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('1.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 40px;
            color: white;
        }
        .container {
            background-color: rgba(43, 32, 32, 0.62);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            max-width: 1000px;
            margin: auto;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: transparent;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ccc;
            color: white;
            text-align: left;
        }
        th {
            background-color: #003366;
        }
        tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        .print-btn {
            background-color: #28a745;
            color: white;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        .print-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>My Billing Records</h2>
        <?php if (count($records) > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Due Date</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
            <?php foreach ($records as $record): ?>
            <tr>
                <td><?= htmlspecialchars($record['id']) ?></td>
                <td>₱<?= number_format($record['amount'], 2) ?></td>
                <td><?= ucfirst(htmlspecialchars($record['status'])) ?></td>
                <td><?= htmlspecialchars($record['due_date']) ?></td>
                <td><?= htmlspecialchars($record['created_at']) ?></td>
                <td>
                    <a class="print-btn" href="generate_pdf.php?id=<?= htmlspecialchars($record['id']) ?>" target="_blank">Print</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php else: ?>
            <p>No billing records found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
