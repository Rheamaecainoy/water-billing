<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Your Profile - H2O Connect</title>
<style>
  /* ... your CSS styles from original profile.php ... */
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    min-height: 100vh;
    background: url('1.jpg') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    color: white;
  }
  .profile-wrapper {
    background-color: rgb(43 32 32 / 62%);
    border-radius: 12px;
    padding: 30px;
    width: 400px;
    box-sizing: border-box;
    box-shadow: 0 8px 24px rgba(0,0,0,0.7);
  }
  h1, h2 {
    color: white;
    margin-bottom: 24px;
    text-align: center;
  }
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: white;
  }
  input[type="text"], input[type="email"], input[type="password"] {
    width: 92%;
    padding: 12px 14px;
    margin-bottom: 20px;
    border: 1.8px solid rgba(255 255 255 / 0.6);
    border-radius: 8px;
    font-size: 1rem;
    background-color: rgba(255 255 255 / 0.15);
    color: white;
    transition: border-color 0.3s ease, background-color 0.3s ease;
  }
  input[readonly] {
    cursor: default;
    background-color: rgba(255 255 255 / 0.1);
  }
  input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus {
    border-color: #60a5fa;
    background-color: rgba(255 255 255 / 0.25);
    outline: none;
    color: white;
  }
  .btn {
    display: block;
    width: 100%;
    padding: 12px 0;
    font-size: 1rem;
    font-weight: 700;
    color: white;
    background-color: #2563eb;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-top: 10px;
  }
  .btn:hover {
    background-color: #1e40af;
  }
  .btn.cancel {
    background-color: #ef4444;
    margin-top: 8px;
  }
  .btn.cancel:hover {
    background-color: #b91c1c;
  }
  .message {
    font-weight: 600;
    padding: 12px;
    margin-bottom: 20px;
    border-radius: 10px;
    text-align: center;
  }
  .success {
    background-color: #dcfce7;
    color: #166534;
    border: 1.5px solid #4ade80;
    color: black;
  }
  .error {
    background-color: #fee2e2;
    color: #991b1b;
    border: 1.5px solid #f87171;
    color: black;
  }
</style>
<script>
  function toggleEdit(enable) {
    let inputs = document.querySelectorAll('input.profile-input');
    inputs.forEach(input => input.readOnly = !enable);

    document.getElementById('edit-btn').style.display = enable ? 'none' : 'block';
    document.getElementById('save-btn').style.display = enable ? 'block' : 'none';
    document.getElementById('cancel-btn').style.display = enable ? 'block' : 'none';
  }

  function cancelEdit() {
    window.location.reload();
  }
</script>
</head>
<body>

<div class="profile-wrapper">
  <h2>Your Profile</h2>

  <?php if (!empty($success)): ?>
    <div class="message success"><?=htmlspecialchars($success)?></div>
  <?php endif; ?>
  <?php if (!empty($error)): ?>
    <div class="message error"><?=htmlspecialchars($error)?></div>
  <?php endif; ?>

  <form method="POST" action="profile.php" autocomplete="off">
    <label for="full_name">Full Name</label>
    <input 
      type="text" 
      id="full_name" 
      name="full_name" 
      class="profile-input" 
      value="<?=htmlspecialchars($user['full_name'])?>" 
      readonly 
      required />

    <label for="email">Email</label>
    <input 
      type="email" 
      id="email" 
      name="email" 
      class="profile-input" 
      value="<?=htmlspecialchars($user['email'])?>" 
      readonly 
      required />

    <label for="phone">Phone</label>
    <input 
      type="text" 
      id="phone" 
      name="phone" 
      class="profile-input" 
      value="<?=htmlspecialchars($user['phone'] ?? '')?>" 
      readonly />

    <label for="password">New Password <small>(Leave blank to keep current password)</small></label>
    <input 
      type="password" 
      id="password" 
      name="password" 
      class="profile-input" 
      placeholder="Enter new password" 
      readonly />

    <button type="button" id="edit-btn" class="btn" onclick="toggleEdit(true)">Edit Profile</button>
    <button type="submit" id="save-btn" class="btn" style="display:none;">Save Changes</button>
    <button type="button" id="cancel-btn" class="btn cancel" style="display:none;" onclick="cancelEdit()">Cancel</button>
  </form>
</div>

</body>
</html>
