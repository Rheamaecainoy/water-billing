<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Customer Dashboard - H2OConnect</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            height: 100vh;
            overflow: hidden;
            background-image: url('1.jpg');
            background-size: cover;
            background-position: center;
        }
        .sidebar {
            width: 220px;
            background-color: #003366;
            color: white;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }
        .sidebar h2 {
            margin-bottom: 30px;
            font-size: 24px;
            color:rgb(255, 255, 255);
            text-align: center;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            margin: 10px 0;
            padding: 12px 15px;
            border-radius: 5px;
            font-weight: 600;
            font-size: 16px;
            display: flex;
            justify-content: space-between;
        }
        .sidebar a .icon {
            margin-left: 12px;
            font-size: 18px;
            color: #00BFFF;
        }
        .sidebar a:hover {
            background-color: #0059b3;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
            padding: 30px;
        }
        .main-content::-webkit-scrollbar {
            display: none;
        }

        /* Remove navbar styles because navbar is removed */

        .content {
            /* padding removed because main-content already has padding */
        }

        .card {
            background-color: rgba(43, 32, 32, 0.62);
            border-radius: 10px;
            padding: 25px 30px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            color: white;
        }
        .card h2 {
            color: white;
            margin-bottom: 20px;
            font-size: 22px;
        }

        /* New style for welcome message inside card */
        .welcome-message {
            color: white;
            margin-bottom: 15px;
        }

        .due-box {
            background: #fff3cd;
            border-left: 6px solid #ffc107;
            padding: 20px;
            border-radius: 8px;
            color: #333;
            text-decoration: none;
            display: block;
            transition: background 0.3s ease;
        }
        .due-box:hover {
            background-color: #ffe8a1;
        }
        .billing-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .billing-table th, .billing-table td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        .billing-table th {
            background-color: #003366;
            color: white;
        }
        .billing-table td {
            color: white;
        }
        .billing-link {
            color: #00bfff;
            text-decoration: none;
            font-weight: 500;
        }
        .billing-link:hover {
            text-decoration: underline;
        }
        .no-record {
            color: #eee;
            font-style: italic;
        }
        .view-more {
            text-align: right;
            margin-top: 10px;
        }
        .view-more a {
            text-decoration: none;
            color: #00bfff;
            font-weight: bold;
        }
        .view-more a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>H2OConnect</h2>
        <a href="profile.php">Profile <span class="icon">👥</span></a>
        <a href="help.php">Help <span class="icon">❓</span></a>
        <a href="logout.php" class="logout">Logout <span class="icon">🚪</span></a>
    </div>

    <div class="main-content">
        <div class="content">
            <div class="card">
                <div class="welcome-message">
                    <h1>Welcome, <?= htmlspecialchars($_SESSION['customer_name']) ?>!</h1>
                    <p>Monitor your water bills, track payments, and view your history.</p>
                </div>

                <h2>Current Amount Due</h2>
                <?php if ($data['unpaid']): ?>
                    <a class="due-box" href="payment.php?billing_id=<?= $data['unpaid']['id'] ?>">
                        <strong>Amount Due:</strong> ₱<?= number_format($data['unpaid']['amount'], 2) ?><br>
                        <strong>Due Date:</strong> <?= htmlspecialchars($data['unpaid']['due_date']) ?>
                    </a>
                <?php else: ?>
                    <p class="no-record">No outstanding bills. You're all caught up!</p>
                <?php endif; ?>
            </div>

            <div class="card">
                <h2><a href="billing_records.php" style="color: inherit; text-decoration: none;">Billing History</a></h2>
                <?php if (count($data['paid_bills']) > 0): ?>
                    <table class="billing-table">
                        <thead>
                            <tr>
                                <th>Bill ID</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Due Date</th>
                                <th>Date Issued</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data['paid_bills'] as $bill): ?>
                                <tr>
                                    <td><a class="billing-link" href="billing_records.php?billing_id=<?= $bill['id'] ?>"><?= $bill['id'] ?></a></td>
                                    <td>₱<?= number_format($bill['amount'], 2) ?></td>
                                    <td><?= ucfirst($bill['status']) ?></td>
                                    <td><?= htmlspecialchars($bill['due_date']) ?></td>
                                    <td><?= htmlspecialchars($bill['created_at']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="view-more">
                        <a href="billing_records.php">View All Billing History &raquo;</a>
                    </div>
                <?php else: ?>
                    <p class="no-record">No paid bills found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
