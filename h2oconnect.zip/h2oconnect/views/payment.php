<!DOCTYPE html>
<html>
<head>
    <title>Pay Your Water Bill</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: url('1.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .payment-box {
            background-color: rgb(43 32 32 / 62%);
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            padding: 40px;
            max-width: 480px;
            width: 100%;
            text-align: center;
            animation: slideUp 0.5s ease-in-out;
            color: white;
        }

        @keyframes slideUp {
            from { transform: translateY(40px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        h1, h2, td {
            color: white;
        }

        .info {
            font-size: 1.1em;
            margin-bottom: 10px;
        }

        .total-box {
            background: #f1f7ff;
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            color: black;
        }

        .total-box p {
            margin: 5px 0;
            font-size: 1.05em;
        }

        .total-box p span {
            float: right;
            font-weight: bold;
        }

        form {
            margin-top: 20px;
        }

        .go-btn, .confirm-btn {
            padding: 12px 25px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1em;
            cursor: pointer;
            margin-top: 20px;
            text-decoration: none;
            display: inline-block;
        }

        .go-btn:hover, .confirm-btn:hover {
            background-color: #218838;
        }

        select {
            padding: 10px;
            font-size: 1em;
            border-radius: 10px;
            border: 1px solid #ccc;
            width: 100%;
            margin-top: 15px;
        }

        .confirmation-message {
            font-size: 1.3em;
            color: lightgreen;
            margin-bottom: 25px;
        }

        .payment-image-wrapper {
            padding: 20px;
            margin-bottom: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f9f9f9;
            border-radius: 12px;
        }

        .payment-logo {
            max-width: 120px;
            height: auto;
        }
    </style>
</head>
<body>

<div class="payment-box">

<?php if ($payment_done && $selected_method): ?>

    <?php
    // Define image path based on selected method
    $method_images = [
        'GCash' => 'gcash.jpg',
        'Maya' => 'maya.webp',
        'GrabPay' => 'grabpay.png'
    ];
    $payment_image = $method_images[$selected_method] ?? '';
    ?>

    <div class="confirmation-message">
        <?php if ($payment_image): ?>
            <div class="payment-image-wrapper">
                <img src="<?= $payment_image ?>" alt="<?= $selected_method ?> Logo" class="payment-logo">
            </div>
        <?php endif; ?>
        <strong>Confirmation Success!</strong><br>
        Please go to <?= htmlspecialchars($selected_method) ?> to pay.
    </div>

    <button id="goButton" class="go-btn">GO</button>

    <script>
        document.getElementById('goButton').addEventListener('click', function() {
            alert('💰 Payment Successful via <?= addslashes($selected_method) ?>!');
            window.location.href = 'dashboard_customer.php';
        });
    </script>

<?php else: ?>

    <h2>Pay Your Bill</h2>
    <div class="info"><strong>Due Date:</strong> <?= htmlspecialchars(date("F j, Y", strtotime($bill['due_date']))) ?></div>

    <div class="total-box">
        <p>Original Amount: <span>₱<?= number_format($baseAmount, 2) ?></span></p>
        <p>Processing Fee (2%): <span>₱<?= number_format($processingFee, 2) ?></span></p>
        <hr>
        <p><strong>Total: <span style="color: #0072ff;">₱<?= number_format($totalAmount, 2) ?></span></strong></p>
    </div>

    <form method="POST" id="paymentForm">
        <label for="pay_method"><strong>Choose Payment Method:</strong></label>
        <select name="pay_method" id="pay_method" required>
            <option value="" disabled selected>Select Method</option>
            <option value="GCash">GCash</option>
            <option value="Maya">Maya</option>
            <option value="GrabPay">GrabPay</option>
        </select>

        <button type="submit" class="confirm-btn">Confirm & Pay</button>
    </form>

<?php endif; ?>

</div>

</body>
</html>
