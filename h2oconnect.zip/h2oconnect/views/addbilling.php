<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Billing Record</title>
    <style>
                * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('1.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
        }

        .form-container {
            background-color: rgba(43, 32, 32, 0.62);
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.3);
            padding: 30px 40px;
            max-width: 500px;
            width: 100%;
            color: white;
        }

        .form-container:hover {
            transform: translateY(-3px);
            transition: 0.3s;
        }

        h1, h2, td {
            color: white;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
        }

        label {
            font-weight: 600;
            display: block;
            margin-top: 20px;
            margin-bottom: 8px;
            color: white;
        }

        select, input[type="number"], input[type="date"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
            background-color: #f9f9f9;
            transition: border-color 0.3s ease;
        }

        select:focus, input:focus {
            border-color: #007BFF;
            outline: none;
            background-color: #fff;
        }

        button {
            margin-top: 25px;
            width: 100%;
            background-color: #007BFF;
            color: #fff;
            padding: 14px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        .msg {
            margin-top: 20px;
            text-align: center;
            font-weight: 600;
            color: #155724;
            background-color: #d4edda;
            padding: 10px 15px;
            border: 1px solid #c3e6cb;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Add Billing Record</h2>
        <form method="POST">
            <label for="customer_id">Customer</label>
            <select name="customer_id" required>
                <option value="">-- Select Customer --</option>
                <?php foreach ($customers as $customer): ?>
                    <option value="<?= $customer['id'] ?>">
                        <?= htmlspecialchars($customer['full_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="amount">Amount (₱)</label>
            <input type="number" name="amount" step="0.01" required>

            <label for="due_date">Due Date</label>
            <input type="date" name="due_date" required>

            <button type="submit">Add Billing</button>

            <?php if ($message): ?>
                <div class="msg"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>
