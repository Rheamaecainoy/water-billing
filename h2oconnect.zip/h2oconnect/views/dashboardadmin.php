<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - H2OConnect</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            height: 100vh;
            overflow: hidden; /* no body scroll */
            background-image: url('1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
        }

        .sidebar {
            width: 220px;
            background-color: #003366;
            color: white;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            font-size: 22px;
            color:rgb(255, 255, 255);
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            margin: 10px 0;
            padding: 10px;
            display: block;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #0059b3;
        }

        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;     /* Firefox */
            padding: 30px;
        }
        .main-content::-webkit-scrollbar {
            display: none;  /* Chrome, Safari and Opera */
        }

        .navbar {
            background-color: transparent;
            padding: 15px 30px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
            display: flex;
            justify-content: flex-end;
            align-items: center;
        }

        .navbar h1 {
            color: white;
            font-size: 24px;
        }

        .content {
            background-color: rgba(43, 32, 32, 0.62);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.7);
            flex-grow: 1;
            overflow-y: auto;
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;     /* Firefox */
        }
        .content::-webkit-scrollbar {
            display: none;  /* Chrome, Safari and Opera */
        }

        .welcome {
            background-color: transparent;
            padding: 10px 0;
            margin-bottom: 20px;
        }

        .welcome h2 {
            color: white;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
        }

        .logout {
            margin-top: auto;
        }

        .search-bar {
            margin-bottom: 20px;
        }

        .search-bar form {
            display: flex;
            max-width: 400px;
        }

        .search-bar input[type="text"] {
            padding: 10px;
            flex-grow: 1;
            border: 1px solid #ccc;
            border-radius: 5px 0 0 5px;
            outline: none;
        }

        .search-bar button {
            padding: 10px 15px;
            background-color: #003366;
            color: white;
            border: none;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #0059b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: transparent;
            box-shadow: none;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            text-align: left;
            color: white;
        }

        th {
            background-color: rgba(0, 51, 102, 0.8);
            color: white;
        }

        tr:hover {
            background-color: rgba(255,255,255,0.1);
        }

        .table-container {
            background-color: rgba(239, 239, 239, 0.53);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.7);
            margin-bottom: 30px;
        }

        .table-container h3 {
            color: white;
            margin-bottom: 10px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
        }
        
    </style>
</head>
<body>

    <div class="sidebar">
    <h2>H2O Admin</h2>
    <a href="admin_billing_records.php">📋 All Billing Records</a>
    <a href="add_billing.php">➕ Add Billing</a>
    <a href="register_admin.php">➕ Add Admin</a> <!-- Add this line -->
    <a href="sales_chart.php">📊 Sales (Chart)</a>
    <a href="sms.php">📨 Send SMS</a>
    <a href="logout.php" class="logout">🚪 Logout</a>
</div>


    <!-- Main Content -->
    <div class="main-content">
        <div class="navbar">
            <h1>H2OConnect Admin Dashboard</h1>
        </div>

        <div class="content">
            <div class="welcome">
                <h2>Welcome, <?= htmlspecialchars($_SESSION['admin_username']) ?>!</h2>
                <p>Manage customer accounts, oversee billing transactions, and track system analytics to ensure efficient service delivery.</p>
            </div>

            <!-- Customer List Section -->
            <div class="table-container">
                <h3>Customer List</h3>

                <div class="search-bar">
                    <form method="GET">
                        <input type="text" name="search" placeholder="Search by customer name..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit">Search</button>
                    </form>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($customers) > 0): ?>
                            <?php foreach ($customers as $customer): ?>
                                <tr>
                                    <td><?= $customer['id'] ?></td>
                                    <td><?= htmlspecialchars($customer['full_name']) ?></td>
                                    <td><?= htmlspecialchars($customer['email']) ?></td>
                                    <td><?= htmlspecialchars($customer['phone']) ?></td>
                                    <td>
    <?= $customer['created_at'] ?>
    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this customer?');">
        <input type="hidden" name="delete_customer_id" value="<?= $customer['id'] ?>">
        <button type="submit" style="margin-left:10px; background-color:red; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer;">Delete</button>
    </form>
</td>

                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5">No customers found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Admin List Section -->
            <div class="table-container">
                <h3>Admin List</h3>

                <div class="search-bar">
                    <form method="GET">
                        <input type="text" name="admin_search" placeholder="Search by admin username..." value="<?= htmlspecialchars($adminSearch) ?>">
                        <button type="submit">Search</button>
                    </form>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($admins) > 0): ?>
                            <?php foreach ($admins as $admin): ?>
                                <tr>
                                    <td><?= $admin['id'] ?></td>
                                    <td><?= htmlspecialchars($admin['username']) ?></td>
                                    <td><?= htmlspecialchars($admin['email']) ?></td>
                                    <td>
    <?= $admin['created_at'] ?>
    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this admin?');">
        <input type="hidden" name="delete_admin_id" value="<?= $admin['id'] ?>">
        <button type="submit" style="margin-left:10px; background-color:red; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer;">Delete</button>
    </form>
</td>

                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4">No admins found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</body>
</html>
