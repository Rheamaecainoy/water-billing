<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>H2O Connect</title>
  <style>
    :root {
      --primary-color: #3b82f6;
      --primary-text-color: white;
      --secondary-color: #e0f2fe;
      --secondary-text-color: #0c4a6e;
      --accent-color: #bae6fd;
      --neutral-light: #f8fafc;
      --neutral-medium: #dbeafe;
      --neutral-dark: #64748b;
      --border-radius: 12px;
      --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      --font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
  font-family: var(--font-family);
  background-image: url('1.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  margin: 0;
  padding: 0;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}


    .chat-wrapper {
      width: 100%;
      max-width: 480px;
      height: 75vh;
      background-color: white;
      border-radius: var(--border-radius);
      box-shadow: var(--box-shadow);
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .chat-header {
      background-color: var(--primary-color);
      color: var(--primary-text-color);
      padding: 16px;
      font-size: 1.25rem;
      font-weight: 600;
      text-align: center;
      user-select: none;
    }

    .chat-container {
      flex: 1;
      padding: 16px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 14px;
      scroll-behavior: smooth;
      background-color: #fafafa;

      /* Hide scrollbar */
      -ms-overflow-style: none;  /* IE and Edge */
      scrollbar-width: none;     /* Firefox */
    }

    .chat-container::-webkit-scrollbar {
      display: none;  /* Chrome, Safari, Opera */
    }

    .bot-msg, .user-msg {
      max-width: 75%;
      padding: 14px 18px;
      border-radius: var(--border-radius);
      font-size: 0.9rem;
      line-height: 1.5;
      word-wrap: break-word;
      box-sizing: border-box;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }

    .bot-msg {
      background-color: var(--secondary-color);
      color: var(--secondary-text-color);
      border: 1px solid var(--accent-color);
      align-self: flex-start;
    }

    .user-msg {
      background-color: var(--primary-color);
      color: var(--primary-text-color);
      align-self: flex-end;
      text-align: right;
      font-weight: 600;
    }

    .suggestions {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 10px;
      justify-content: flex-start;
    }

    .suggestion-btn {
      background-color: var(--neutral-light);
      color: var(--primary-color);
      border: 1.5px solid var(--accent-color);
      border-radius: 20px;
      padding: 8px 18px;
      font-size: 0.85rem;
      cursor: pointer;
      transition: background-color 0.25s ease, color 0.25s ease;
      user-select: none;
    }

    .suggestion-btn:hover,
    .suggestion-btn:focus {
      background-color: var(--accent-color);
      color: var(--secondary-text-color);
      outline: none;
    }

    .back-btn {
      background-color: var(--neutral-light);
      color: var(--primary-color);
      border: 1.5px solid var(--accent-color);
      padding: 8px 20px;
      font-size: 0.85rem;
      border-radius: 20px;
      cursor: pointer;
      margin: 12px auto;
      display: none;
      user-select: none;
      transition: background-color 0.25s ease;
    }

    .back-btn:hover,
    .back-btn:focus {
      background-color: var(--accent-color);
      outline: none;
    }

    .chat-input {
      display: flex;
      border-top: 1px solid var(--neutral-medium);
      padding: 10px 16px;
      background-color: white;
    }

    .chat-input input {
      flex: 1;
      border: 1.5px solid var(--neutral-medium);
      border-radius: 24px;
      padding: 10px 16px;
      font-size: 0.9rem;
      outline: none;
      transition: border-color 0.3s ease;
      font-family: var(--font-family);
    }

    .chat-input input:focus {
      border-color: var(--primary-color);
    }

    .chat-input button {
      background-color: var(--primary-color);
      color: var(--primary-text-color);
      border: none;
      margin-left: 12px;
      padding: 10px 22px;
      font-size: 0.9rem;
      font-weight: 600;
      border-radius: 24px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      user-select: none;
    }

    .chat-input button:hover,
    .chat-input button:focus {
      background-color: #2563eb;
      outline: none;
    }

    .typing {
      font-style: italic;
      color: var(--neutral-dark);
      align-self: flex-start;
      font-size: 0.9rem;
      user-select: none;
    }
  </style>
</head>
<body>

  <div class="chat-wrapper">
    <div class="chat-header">Chatbot</div>
    <div class="chat-container" id="chat">
      <div class="bot-msg">Hi there! What would you like help with?</div>
      <div class="suggestions" id="suggestions">
        <?php foreach ($suggestions as $index => $question): ?>
          <button class="suggestion-btn" onclick="handleSuggestion(<?= $index ?>)"><?= htmlspecialchars($question) ?></button>
        <?php endforeach; ?>
      </div>
    </div>

    <button class="back-btn" id="backBtn" onclick="location.reload()">Back</button>

    <div class="chat-input">
      <input type="text" id="userInput" placeholder="Type your message..." onkeypress="handleKeyPress(event)" autocomplete="off" />
      <button onclick="handleTextSubmit()">Send</button>
    </div>
  </div>

  <script>
    const chat = document.getElementById("chat");

    const suggestions = <?php echo json_encode($suggestions); ?>;
    const answers = <?php echo json_encode($answers); ?>;

    function appendMessage(content, className) {
      const msg = document.createElement("div");
      msg.className = className;
      msg.textContent = content;
      chat.appendChild(msg);
      chat.scrollTop = chat.scrollHeight;
      return msg;
    }

    function showTyping(callback) {
      const typing = document.createElement("div");
      typing.className = "typing";
      typing.textContent = "Bot is typing...";
      chat.appendChild(typing);
      chat.scrollTop = chat.scrollHeight;

      setTimeout(() => {
        chat.removeChild(typing);
        callback();
      }, 800);
    }

    function showBackButton() {
      document.getElementById("backBtn").style.display = "block";
    }

    function handleSuggestion(index) {
      appendMessage(suggestions[index], "user-msg");
      showTyping(() => {
        appendMessage(answers[index], "bot-msg");
        showBackButton();
      });
    }

    function handleTextSubmit() {
      const input = document.getElementById("userInput");
      const userText = input.value.trim();
      if (!userText) return;
      appendMessage(userText, "user-msg");
      input.value = "";
      showTyping(() => {
        appendMessage("Thanks for your message! We'll get back to you shortly.", "bot-msg");
        showBackButton();
      });
    }

    function handleKeyPress(e) {
      if (e.key === "Enter") {
        handleTextSubmit();
      }
    }
  </script>

</body>
</html>
