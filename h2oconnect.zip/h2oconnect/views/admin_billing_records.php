<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Billing Records - Admin</title>
    <!-- Include your styles here... -->
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background-image: url('1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            padding: 30px;
            overflow: hidden;
        }

        .navbar {
            text-align: center;
            margin-bottom: 20px;
        }

        .navbar h1 {
            font-size: 28px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
        }

        .content {
            background-color: rgba(43, 32, 32, 0.62);
            padding: 20px;
            border-radius: 10px;
            max-height: calc(100vh - 130px);
            overflow-y: auto;
            box-shadow: 0 2px 5px rgba(0,0,0,0.7);
        }

        .content::-webkit-scrollbar {
            display: none;
        }

        .search-form {
            margin-bottom: 20px;
        }

        .search-form input[type="text"] {
            padding: 10px 15px;
            font-size: 14px;
            border: none;
            border-radius: 6px;
            outline: none;
            width: 200px;
            margin-bottom: 10px;
        }

        .table-container {
            background-color: rgb(119 119 119 / 53%);
            padding: 20px;
            border-radius: 10px;
        }

        .table-container h3 {
            color: white;
            margin-bottom: 10px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.7);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: transparent;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            text-align: left;
            color: white;
        }

        th {
            background-color: rgba(0, 51, 102, 0.8);
        }

        tr:hover {
            background-color: rgba(255,255,255,0.1);
        }

        .status-paid {
            color: lightgreen;
            font-weight: bold;
        }

        .status-unpaid {
            color: #ff4d4d;
            font-weight: bold;
        }

        .status-overdue {
            color: orange;
            font-weight: bold;
        }

        a.phone-link {
            color: #b3e5fc;
            text-decoration: underline;
        }

        a.phone-link:hover {
            color: #ffffff;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .top-bar form {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>All Billing Records</h1>
    </div>

    <div class="content">
        <div class="top-bar">
            <form class="search-form" method="GET">
                <input type="text" name="search" placeholder="Search status..." value="<?= htmlspecialchars($filter) ?>">
            </form>
        </div>

        <div class="table-container">
            <h3>Customer Billing Records</h3>
            <?php if (count($records) > 0): ?>
            <table>
                <tr>
                    <th>Record ID</th>
                    <th>Customer Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Due Date</th>
                    <th>Created At</th>
                    <th>Paid At</th>
                </tr>
                <?php foreach ($records as $record): 
                    $statusClass = 'status-unpaid';
                    if ($record['status'] === 'paid') {
                        $statusClass = 'status-paid';
                    } elseif ($record['status'] === 'overdue') {
                        $statusClass = 'status-overdue';
                    }

                    $phone = htmlspecialchars($record['phone']);
                    $smsLink = "sms.php?recipient=" . urlencode($phone);
                ?>
                <tr>
                    <td><?= htmlspecialchars($record['id']) ?></td>
                    <td><?= htmlspecialchars($record['full_name']) ?></td>
                    <td><?= htmlspecialchars($record['email']) ?></td>
                    <td><a href="<?= $smsLink ?>" class="phone-link"><?= $phone ?></a></td>
                    <td>₱<?= number_format($record['amount'], 2) ?></td>
                    <td class="<?= $statusClass ?>"><?= ucfirst($record['status']) ?></td>
                    <td><?= htmlspecialchars($record['due_date']) ?></td>
                    <td><?= htmlspecialchars($record['created_at']) ?></td>
                    <td><?= $record['paid_at'] ? htmlspecialchars($record['paid_at']) : '—' ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php else: ?>
                <p>No billing records found for "<?= htmlspecialchars($filter) ?>".</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
