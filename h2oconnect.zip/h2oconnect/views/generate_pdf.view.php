<?php
require_once 'fpdf/fpdf.php';

function generatePDFView($record) {
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', '', 12);

    // Logo
    if (file_exists('H2O CONNECT.jpg')) {
        $pdf->Image('H2O CONNECT.jpg', 10, 6, 30);
    }

    $pdf->SetY(15);
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Water Billing Receipt', 0, 1, 'C');
    $pdf->Ln(10);

    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Customer Name: ' . $record['full_name'], 0, 1, 'C');
    $pdf->Cell(0, 10, 'Email: ' . $record['email'], 0, 1, 'C');
    $pdf->Cell(0, 10, 'Amount Due: ' . number_format($record['amount'], 2), 0, 1, 'C');
    $pdf->Cell(0, 10, 'Status: ' . ucfirst($record['status']), 0, 1, 'C');
    $pdf->Cell(0, 10, 'Due Date: ' . $record['due_date'], 0, 1, 'C');
    $pdf->Cell(0, 10, 'Date Issued: ' . $record['created_at'], 0, 1, 'C');
    $pdf->Ln(15);

    $pdf->SetFont('Arial', 'I', 11);
    $pdf->MultiCell(0, 10, "Thank you for using H2OConnect.\nPlease present this receipt as proof of your payment.", 0, 'C');

    $pdf->Output('I', 'billing_receipt.pdf');
}
