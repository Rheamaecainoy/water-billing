<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Help & Support - H2OConnect</title>
    <style>
        /* Your existing CSS here */
        * {
            margin: 0; 
            padding: 0; 
            box-sizing: border-box;
        }
        html, body {
            height: 100%;
            font-family: 'Segoe UI', sans-serif;
            background: url('1.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }

        .container {
            max-width: 1000px;
            margin: 50px auto;
            background-color: rgb(43 32 32 / 62%);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.5);
        }

        h1, h2, td {
            color: #fff;
        }

        h1 {
            margin-bottom: 10px;
            font-size: 28px;
        }

        h2 {
            margin-top: 40px;
            font-size: 24px;
            border-left: 6px solid #00BFFF;
            padding-left: 12px;
        }

        .contact-box {
            background: rgba(230, 247, 255, 0.2);
            border: 1px solid rgba(179, 224, 255, 0.3);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            color: #e0e7ff;
        }

        .question-box {
            margin-top: 40px;
            padding: 30px;
            background-color: rgba(240, 248, 255, 0.15);
            border: 1px solid rgba(179, 217, 255, 0.3);
            border-radius: 12px;
            text-align: center;
            color: #e0e7ff;
        }

        .question-box h3 {
            font-size: 22px;
            margin-bottom: 10px;
        }

        .question-box p {
            font-size: 16px;
            color: #d1d5db;
            margin-bottom: 20px;
        }

        .question-box a {
            display: inline-block;
            text-decoration: none;
            background-color: #003366;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: bold;
            transition: background 0.3s;
        }

        .question-box a:hover {
            background-color: #0059b3;
        }

        .back {
            display: inline-block;
            margin-top: 30px;
            text-decoration: none;
            color: #ffffff;
            background: #003366;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        .back:hover {
            background: #0059b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Help & Support</h1>
        <p>We're here to assist you with your water billing needs. Please see our contact information below or reach out with your questions.</p>

        <h2>📞 Customer Service Contact</h2>
        <div class="contact-box">
            <p><strong>Support Admin:</strong> <?= htmlspecialchars($admin['username']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($admin['email']) ?></p>
            <p><strong>Available:</strong> Monday - Friday, 9:00 AM - 5:00 PM</p>
        </div>

        <div class="question-box">
            <h3>Have Questions?</h3>
            <p>Find answers to the most common questions asked by customers.</p>
            <a href="chatbot.php">Find Answer</a>
        </div>

    </div>

</body>
</html>
