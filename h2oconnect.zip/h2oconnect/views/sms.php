<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send SMS - H2OConnect</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: rgba(43, 32, 32, 0.7);
            margin-top: 40px;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
            width: 90%;
            max-width: 500px;
        }

        h1 {
            text-align: center;
            color: white;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 15px;
            font-weight: bold;
            color: white;
        }

        input[type="text"],
        textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-top: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        button {
            margin-top: 20px;
            padding: 12px;
            background-color: #0077cc;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        button:hover {
            background-color: #005fa3;
        }

        .message {
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
        }

        .success {
            color: lightgreen;
        }

        .error {
            color: #ff8080;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Send SMS</h1>

    <?php if ($message_sent): ?>
        <div class="message success">✅ SMS sent successfully!</div>
    <?php elseif (!empty($error_message)): ?>
        <div class="message error">❌ <?= htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <form method="post">
        <label for="recipient">Recipient Number:</label>
        <input type="text" name="recipient" id="recipient"
               pattern="09[0-9]{9}" maxlength="11" inputmode="numeric"
               placeholder="e.g. 09123456789"
               value="<?= htmlspecialchars($prefill_phone) ?>" required>

        <label for="message">Message:</label>
        <textarea name="message" id="message" placeholder="Type your message here..." required></textarea>

        <button type="submit">Send SMS</button>
    </form>
</div>

</body>
</html>
