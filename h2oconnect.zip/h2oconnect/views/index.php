<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to H2OConnect</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('1.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #ffffff;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background-color: rgb(43 32 32 / 62%);
            color: #ffffff;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            padding: 40px;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
        }

        h1, h2 {
            color: #ffffff;
        }

        h1 {
            font-size: 2.5rem;
            margin-bottom: 30px;
        }

        .section {
            margin: 30px 0;
        }

        .button-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 16px;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0, 123, 255, 0.2);
            min-width: 150px;
        }

        button:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 86, 179, 0.3);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 500px) {
            .container {
                padding: 25px;
            }

            button {
                font-size: 14px;
                padding: 10px 20px;
                min-width: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to H2OConnect</h1>

        <div class="section">
            <h2>Customer Access</h2>
            <div class="button-group">
                <button onclick="location.href='login_customer.php'">Login</button>
                <button onclick="location.href='register_customer.php'">Register</button>
            </div>
        </div>

        <div class="section">
            <h2>Admin Access</h2>
            <div class="button-group">
                <button onclick="location.href='login_admin.php'">Login</button>
            </div>
        </div>
    </div>

    <script>
        console.log("H2OConnect Index Page Loaded");
    </script>
</body>
</html>
