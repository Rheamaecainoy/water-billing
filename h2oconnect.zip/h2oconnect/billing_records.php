<?php
session_start();
require_once 'db.php';
require_once 'controllers/billingrecordsController.php';

$controller = new BillingRecordsController($pdo);
$controller->handleRequest();
