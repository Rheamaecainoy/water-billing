<?php
require_once 'controllers/logincustomerController.php';

session_start();
$controller = new LoginCustomerController();
$controller->handleRequest();
