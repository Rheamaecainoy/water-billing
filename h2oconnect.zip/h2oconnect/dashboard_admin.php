<?php
session_start();
require_once 'controllers/dashboardadminController.php';

$controller = new DashboardAdminController();
$controller->handleRequest();
