<?php
require_once 'controllers/generatepdf.controller.php';

$controller = new GeneratePDFController();
$controller->handleRequest();
